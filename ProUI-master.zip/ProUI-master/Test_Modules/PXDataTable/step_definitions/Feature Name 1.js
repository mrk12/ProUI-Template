module.exports = function () {
    this.Given(/I go to the URL$/, function (callback) {
        browser.driver.get(browser.params.login.baseUrl);
        browser.driver.isElementPresent(by.css('.delta.style-scope.px-demo-header')).then(function (bool) {
            browser.ignoresynchronization = true;
            callback();

        });

    });
    this.Given(/^I check the image at the homepage$/, function (callback) {
        browser.ignoresynchronization = false;
        browser.waitForAngular();
        browser.sleep(15000).then(function () {

            browser.findElement(element(by.id("frameEl"))).then(function (ele) {
                browser.switchTo().frame(ele).then(function () {
            browser.ignoresynchronization = true;
            TestHelper.iFrameSwitch("Predix_ProUI_TestPage","iframe").then(function () {
                console.log("Switched Iframe");
                TestHelper.isElementPresent(element(by.css('px-data-table'))).then(function () {
                    PXDataTable.initialize(element(by.css('px-data-table')));
                    browser.sleep(9000).then(function () {
                        PXDataTable.getCurrentPage().then(function (count) {
                            console.log("The column count is: " + count);
                            callback();
                        })
                    });
                });
            });
//             callback();
        });
        });
    });
    });


}
